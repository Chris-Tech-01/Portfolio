export { 
    getRandomNumber, 
    toggleSidebar
} from './sidebar.js';

export { 
    toggleBurgerMenu,
    bannerTyping
} from './banner.js';

export { 
    validateContactForm
} from './formValidation.js';


